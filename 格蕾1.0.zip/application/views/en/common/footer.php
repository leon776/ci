<div class="slide footer">
    <div class="container">
        <div class="row">	
            <div class="col-sm-12 col-md-9 row1"> 
        		©  GREY MEDICAL 粤ICP备 15019080号
            </div>			 
            <div class="col-sm-12 col-md-3 row2" style="text-align:right">
                <a href="index.php/law" title="legal-notice">Legal-Notice</a>   
                 |             
                <a href="index.php/contact" title="Contact Us">Contact Us</a>               
            </div>		
        </div>    	
    </div><!-- /.container -->
</div><!-- /.section.footer -->    
<ul id="tbox">
    <li><a id="gotop" href="javascript:void(0)" style="display: block;"></a></li> 
</ul><!-- /#tbox --> 

<script src="assets/js/jquery-1.10.2.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/common.min.js"></script>  
</body>
</html>