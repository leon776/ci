<link href="assets/css/contact.css" rel="stylesheet">

<div class="slide page-heading">
     <div class="container">
        <h1>About Us</h1> 
     </div>
</div> 
 
<div class="slide about">
    <div class="container">     
        <ul class="about_advantage"> <!-- 注意此处列表单双有区别: <li class="list dual"> -->
        <li class="list">
            <p class="pic"><img src="assets/en/images/about_1.png" alt="Advantage is introduced"></p> 
            <h3>Advantage is introduced</h3>
            <p>With the continuous improvement of the national income level, domestic and international information exchanges increased gradually, more and more mainland residents began around the world looking for better medical resources, as long as conditions allow, also can enjoy the advanced overseas domestic patients developed medical services.. Although medical expense is higher than domestic, its medical service has obvious advantages: one is superb medical technology; The second is the advanced medical equipment; Three is a strong sense of responsibility, has the professional dedication of </p> 
        </li>
        <li class="list dual">
            <p class="pic"><img src="assets/en/images/about_2.png" alt="Medical Resources"></p> 
            <h3>Medical Resources</h3>
            <p>The doctor, one for China's middle and high class, base of consumers In the global mobile Internet medical and health care service platform. It will be up Step in Hong Kong, and gradually will complete systems and services to expand to the whole world High quality medical services in the world.</p> 
        </li>
        <li class="list">
            <p class="pic"><img src="assets/en/images/about_3.png" alt="Differentiated Products"></p> 
            <h3>Differentiated Products</h3>
            <p>Product Differentiation (Product Differentiation) refers to the enterprise to change the same Product in some way, in order to make consumers trust Product differentiation The differences between products and produce different preferences. According to the theory of industrial organization, the product difference is one of the main elements of market structure, the corporate control market depends on them to make their own degree of successful product differentiation. In addition to perfect competition (product homogeneity) and oligopoly market (single), usually the product difference is universal. Enterprise that is different with other products products have an absolute monopoly, the monopoly to construct the other enterprises to enter the market or industry barriers, form a competitive advantage</p> 
        </li>
        </ul> <!-- /.about_advantage -->  
    </div><!-- /.container -->
</div><!-- /.slide.contact-form -->  

