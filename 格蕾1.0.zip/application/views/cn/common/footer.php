<div class="slide footer">
    <div class="container">
        <div class="row">	
            <div class="col-sm-12 col-md-9 row1"> 
        		© 格蕾医疗网 粤ICP备 15019080号
            </div>			 
            <div class="col-sm-12 col-md-3 row2" style="text-align:right">
                <a href="index.php/law" title="法律声明">法律声明</a>
                 | 
                <a href="index.php/contact" title="联系我们">联系我们</a>
            </div>		
        </div>    	
    </div><!-- /.container -->
</div><!-- /.section.footer -->    
<ul id="tbox">
    <li><a id="gotop" href="javascript:void(0)" style="display: block;"></a></li> 
</ul><!-- /#tbox --> 

<script src="assets/js/jquery-1.10.2.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/common.min.js"></script>  
</body>
</html>