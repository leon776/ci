<link href="assets/css/contact.css" rel="stylesheet">

<div class="slide page-heading">
     <div class="container">
        <h1>关于我们</h1> 
     </div>
</div>
 
<div class="slide about">
    <div class="container">     
        <ul class="about_advantage"> <!-- 注意此处列表单双有区别: <li class="list dual"> -->
        <li class="list">
            <p class="pic"><img src="assets/images/about_1.png" alt="优势介绍"></p> 
            <h3>优势介绍</h3>
            <p>打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈</p> 
        </li>
        <li class="list dual">
            <p class="pic"><img src="assets/images/about_2.png" alt="医疗资源"></p> 
            <h3>医疗资源</h3>
            <p>打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈</p> 
        </li>
        <li class="list">
            <p class="pic"><img src="assets/images/about_3.png" alt="差异化产品"></p> 
            <h3>差异化产品</h3>
            <p>打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈</p> 
        </li>
        </ul> <!-- /.about_advantage -->  
    </div><!-- /.container -->
</div><!-- /.slide.contact-form -->  