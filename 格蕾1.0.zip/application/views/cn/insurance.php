<link href="assets/css/work.css" rel="stylesheet">
<div class="slide page-heading">
     <div class="container">
        <h1>全球医保</h1>
     </div>
</div>
 
<div class="slide insurance_1">
     <div class="container">
        <h3 class="name">优势介绍</h3>
        <div class="txt">
            <p>打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快<br>
            过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，<br>
            提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提<br>
            供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈</p>
        </div>
        <div class="pic"><img src="assets/images/insurance_1.png" alt=""></div>
     </div>
</div>

<div class="slide insurance_2">
     <div class="container">
        <h3 class="name">产品简介</h3>
        <div class="txt">
            <p>打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快<br>
            过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，<br>
            提供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈，打通亚洲4小时医疗圈，提<br>
            供一站式行程安排，医病速度快过国内,打通亚洲4小时医疗圈</p>
        </div>
        <div class="pic"><img src="assets/images/insurance_2.png" alt=""></div>
     </div>
</div>

<div id="slide-portfolio" class="slide portfolio">
    <div class="container">
        <h2 class="title">合作伙伴</h2>
        <div id="module-ajax-list" class="row grid cs-style-3"> <!-- 上传图片大小：360*285px -->
    
            <div class='col co-xs-6 col-sm-6 col-md-3'>
                <figure>
                    <img src='assets/upload/insurance_1.jpg'  alt='香港玛丽医院'>
                    <figcaption>
                        <div class="name">
                            <h3>香港玛丽医院</h3>
                            <span>Queen Marry Hospital</span> 
                        </div>
                    </figcaption>
                </figure>
            </div>
        
            <div class='col co-xs-6 col-sm-6 col-md-3'>
                <figure>
                    <img src='assets/upload/insurance_2.jpg'  alt='香港玛丽医院'>
                    <figcaption>
                        <div class="name">
                            <h3>香港玛丽医院</h3>
                            <span>Queen Marry Hospital</span> 
                        </div>
                    </figcaption>
                </figure>
            </div>
        
            <div class='col co-xs-6 col-sm-6 col-md-3'>
                <figure>
                    <img src='assets/upload/insurance_3.jpg'  alt='香港玛丽医院'>
                    <figcaption>
                        <div class="name">
                            <h3>香港玛丽医院</h3>
                            <span>Queen Marry Hospital</span> 
                        </div>
                    </figcaption>
                </figure>
            </div>
        
            <div class='col co-xs-6 col-sm-6 col-md-3'>
                <figure>
                    <img src='assets/upload/insurance_4.jpg'  alt='香港玛丽医院'>
                    <figcaption>
                        <div class="name">
                            <h3>香港玛丽医院</h3>
                            <span>Queen Marry Hospital</span> 
                        </div>
                    </figcaption>
                </figure>
            </div> 
        
            <div class='col co-xs-6 col-sm-6 col-md-3'>
                <figure>
                    <img src='assets/upload/insurance_5.jpg'  alt='香港玛丽医院'>
                    <figcaption>
                        <div class="name">
                            <h3>香港玛丽医院</h3>
                            <span>Queen Marry Hospital</span> 
                        </div>
                    </figcaption>
                </figure>
            </div> 
        
            <div class='col co-xs-6 col-sm-6 col-md-3'>
                <figure>
                    <img src='assets/upload/insurance_6.jpg'  alt='香港玛丽医院'>
                    <figcaption>
                        <div class="name">
                            <h3>香港玛丽医院</h3>
                            <span>Queen Marry Hospital</span> 
                        </div>
                    </figcaption>
                </figure>
            </div> 
        
            <div class='col co-xs-6 col-sm-6 col-md-3'>
                <figure>
                    <img src='assets/upload/insurance_7.jpg'  alt='香港玛丽医院'>
                    <figcaption>
                        <div class="name">
                            <h3>香港玛丽医院</h3>
                            <span>Queen Marry Hospital</span> 
                        </div>
                    </figcaption>
                </figure>
            </div> 
        
            <div class='col co-xs-6 col-sm-6 col-md-3'>
                <figure>
                    <img src='assets/upload/insurance_8.jpg'  alt='香港玛丽医院'>
                    <figcaption>
                        <div class="name">
                            <h3>香港玛丽医院</h3>
                            <span>Queen Marry Hospital</span> 
                        </div>
                    </figcaption>
                </figure>
            </div> 
                
        </div><!-- /.row -->
    </div>
</div><!-- /.slide.categories -->