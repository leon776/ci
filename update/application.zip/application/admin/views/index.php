<div class="main">
	
	<iframe src="" onload="common.iFrameHeight(this)" frameborder="0" width="100%" id="iframe" style="opacity:0;-webkit-transition:opacity .25s ease-in-out;">
		
	</iframe>
	<script language="javascript">
		common.$("iframe").src = "<?php echo $iframe;?>";
	</script>
</div>
<!--main-->
</div>
<!--content-->