<!DOCTYPE HTML>
<html class="not-ie" lang="en">
<head>
	<meta charset="utf-8" />
	<title><?php echo $title ?></title>
	<link rel="stylesheet" href="<?php echo base_url("style/css/bootstrap.css")?>"/>
	<link rel="stylesheet" href="<?php echo base_url("style/css/todc-bootstrap.css")?>"/>
	<link rel="stylesheet" href="<?php echo base_url("style/css/style.css")?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("js/jquery.fancybox-1.3.4/fancybox/jquery.fancybox-1.3.4.css")?>" media="screen" />
	<script type="text/javascript" src="<?php echo base_url('js/jquery.min.js');?>"></script>
	<script type="text/javascript" src="<?php echo base_url('js/common.js');?>"></script>
	<script language="javascript">var common = new common("<?php echo base_url();?>");</script>
</head>
<body>
