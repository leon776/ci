<link href="assets/css/work.css" rel="stylesheet">
<div class="slide page-heading">
     <div class="container">
        <h1>Legal notices</h1>
     </div>
</div>
 
<div class="slide insurance_1">
     <div class="container">
        <div class="legal-notice">
            <p>All the contents of this web site contains: text, graphics, logos, creativity, and ownership of software, such as Hohhot travel network in north China and the content of this website/information provider, shall be protected by the Chinese and international copyright laws. The copy of all content on this site (refers to the collection, combination and recombination), on this web site shall enjoy the right of exclusive and protected by Chinese and international copyright laws. The ownership of all software used on this web site belongs to Hohhot in northern China travel network or its software suppliers and protected by Chinese and international copyright laws. Specific information on this site, with permission of the site can be reproduced, and indicate the source.</p>
            <h4>Information release clause</h4>
            <p>Hohhot, northern China travel network can only be used for legal purposes, namely view information, online consulting, user communication.</p>
            <p>(1) prohibit the publication of the information published in shortage or false information, if discover the user violates the relevant provisions, and we will keep to suspend or terminate the service to the users.<br>
(2) all of the information in this website, all may not be in violation of state and local governments on Internet network information security rules, regulations, the provisions of the measures for the administration and other relevant laws and regulations;<br>
Information content published by the 
(3) to release the user is responsible for the interpretation of the information, and independently bear all the resulting consequences and legal responsibilities.<br>
(4) the user shall have the right to use the site through the web site all the information, while retaining the release information to the user management, modify, delete, right;<br>
(5) without authorization, this website user is prohibited from this site information used for other purposes.</p>  
            <h4>The user privacy policy</h4>
            <p>Respect user privacy is Hohhot in northern China travel network user service of a basic policy. Hohhot, northern China travel network will not be without legal user authorization to a third party or publicly disclosed the registered information and saved in Hohhot travel network users in north China platform of non-public content, except the following:</p>
            <p>(1) the user for their improper information confidential reason, lead to users non-public information disclosure;<br>
(2) due to network line, hacker attack, computer virus, causes such as government regulation of information disclosure, lost, stolen or tampered, etc;<br>
(3) the relevant laws or Hohhot in northern China travel network service management required to provide the user's personal information;<br>
(4) in case of an emergency for maintenance of users and the public life and property safety.
            </p>
            <h4>Service termination clause</h4>
            <p>(1) Hohhot travel network in north China have determine the user's behavior is in accordance with the terms of this service request, if the Hohhot travel network in north China that the user has violated the provisions of the terms of service, have the right to immediately terminate its customer service and to delete the user information;<br>
            (2) Diction Hohhot in northern China travel network can be modified at any time according to actual condition, interrupt or stop the user free service in part or in full, and don't need to tell any user or the third party rights.</p>
            
            
            <h4>disclaimer</h4>
            <p>(1) does not guarantee that this website provides the free service will not be modified, interrupt, termination, delay, also cannot guarantee absolute integrity and security of user information, be free service to the user to modify, interruption, termination, delay and loss of user information, this site does not assume any responsibility;<br>
            (2) this website only for their own and entrusted by Hohhot tourism bureau release information guarantee the authenticity, legality, accuracy, no guarantee in addition to other users publish information content the authenticity, legality, accuracy, and its information content must be confirmed by the visitors themselves and assume the risk of using this information, at the same time, this site does not assume other users except its own release false information loss and responsibility.</p>
        
        </div>
     </div>
</div>